"use strict";

const inputWiringDelay = document.querySelector("#inputWiringDelay");
const inputWiringHeight = document.querySelector("#inputWiringHeight");
const selectWiringLanding = document.querySelector("#selectWiringLanding");
const selectWiringOrder = document.querySelector("#selectWiringOrder");
const buttonFindWiring = document.querySelector("#buttonFindWiring");
const checkWiringView = document.querySelector("#checkWiringView");
const canvasWiring = document.querySelector("#canvasWiring");
const spanWiringResults = [...document.querySelectorAll(".spanWiringResults")];
const message = document.querySelector("#message");

const asset = dataAssets.wing.ground;
const partsNames = [
  "noteU", "noteD", "space", "openU", "openD", "close", "connection", "middle"
];

let resultsList;

function isNum(...values) {
  return values.every(value => value !== "" && Number.isInteger(Number(value)));
}

function findWiringResults(delay, height) {
  const resultsList = [[], [], []];
  const { relativeRailDelays, accelerationsList, upOptions, gaps } = asset;
  const accelerations = accelerationsList[selectWiringLanding.value];
  const accelerationsLen = accelerations.length;

  function getAcceleration(distance) {
    return (distance <= accelerationsLen) ? accelerations[distance - 1] : 0;
  }

  const upOptionsLen = upOptions.length;
  const gapsLen = gaps.length;

  function addDownOption(_delay, _distance, count, _str) {
    for (let g = 0; g < gapsLen; g++) {
      const gap = gaps[g];
      let dDelay = 0;
      let d = 1;

      for (;;) {
        const distance = _distance - (gap.down + d * 2);
        if (distance <= 0) {
          if (d === 1) return;
          break;
        }

        dDelay += relativeRailDelays[(gap.offset + d - 1) % 3];

        const optionDelay = _delay + gap.delay + dDelay;
        const totalDelay = optionDelay - getAcceleration(distance);
        const str = `${_str}G${gap.down}R${d}`;
        const difference = totalDelay - delay;
        const error = Math.abs(difference);

        if (error <= 2) {
          resultsList[error].push({
            delay: totalDelay,
            up: startingUp,
            down: height - distance,
            str
          });
          break;
        }

        if (difference > 0) break;
        if (count > 1) addDownOption(optionDelay, distance, count - 1, str);
      }
    }
  }

  let startingUp;

  for (let u = 0; u < upOptionsLen; u++) {
    const upOption = upOptions[u];
    startingUp = upOption.up;

    let dDelay = 0;
    let d = 0;

    for (;;) {
      const startingDown = d * 2;
      const distance = height - startingDown;
      if (distance <= 0) break;

      if (d !== 0) dDelay += relativeRailDelays[(upOption.offset + d - 1) % 3];

      const startingDelay = upOption.delay + dDelay;
      const totalDelay = startingDelay - getAcceleration(distance);
      const str = `${upOption.str}-${d === 0 ? "" : "R" + d}`;
      const difference = totalDelay - delay;
      const error = Math.abs(difference);

      if (error <= 2) {
        resultsList[error].push({
          delay: totalDelay,
          up: startingUp,
          down: startingDown,
          str
        });
        break;
      }

      if (difference > 0) break;

      addDownOption(startingDelay, distance, 3, str);
      d++;
    }
  }

  return resultsList;
}

function clearResults() {
  spanWiringResults.forEach(container => { container.replaceChildren(); });
}

function setCanvasHeight(height = 320) {
  canvasWiring.height = height;
  canvasWiring.style.height = `${height}px`;
}

function drawWiring(str) {
  const direction = str[0];
  const optsList = [];
  const parts = [];

  str.split("-").forEach(optionsStr => {
    optsList.push(optionsStr.match(/[RGF]\d*/g) || []);
  });

  if (direction === "↑") {
    optsList[0].forEach((option, i) => {
      switch (option[0]) {
        case "R":
          if (i === 0) {
            if (option[1] === "0") parts.unshift(5);
            else {
              parts.unshift(6);
              [...Array(Number(option.slice(1)) - 1)].forEach(() => parts.unshift(6, 7));
              parts.unshift(i < optsList[0].length - 1 ? 3 : 5, 7);
            }
          } else {
            parts.unshift(4);
            [...Array(Number(option.slice(1)) - 1)].forEach(() => parts.unshift(6, 7));
            parts.unshift(i < optsList[0].length - 1 ? 3 : 5, 7);
          }
          break;
        case "G":
          if (i === 0) parts.unshift(3);
          [...Array(Number(option.slice(1)) - 1)].forEach(() => parts.unshift(2));
          break;
        case "F":
          if (i === 0) parts.unshift(3);
          break;
        default:
          break;
      }
    });
    parts.push(0);
  } else {
    parts.unshift(3);
    parts.push(1);
  }

  if (optsList[1].length === 0) parts.push(4);

  optsList[1].forEach((option, i) => {
    if (option[0] === "R") {
      parts.push(i === 0 ? 6 : 3);
      [...Array(Number(option.slice(1)) - 1)].forEach(() => parts.push(7, 6));
      parts.push(7, 4);
    } else {
      if (i === 0) parts.push(4);
      [...Array(Number(option.slice(1)) - 1)].forEach(() => parts.push(2));
    }
  });

  const context = canvasWiring.getContext("2d");
  const canvasHeight = 32 * parts.length;
  canvasWiring.height = canvasHeight;
  canvasWiring.style.height = `${canvasHeight}px`;
  context.imageSmoothingEnabled = false;
  context.clearRect(0, 0, 32, canvasHeight);

  parts.forEach((part, i) => {
    const image = new Image();
    image.src = `images/railParts/${partsNames[part]}.png`;
    image.onload = () => context.drawImage(image, 0, 32 * i, 32, 32);
  });
}

function setWiringResult() {
  if (!resultsList) return;

  const sortIndex = selectWiringOrder.selectedIndex;
  const sorters = [
    (a, b) => a.up - b.up || a.down - b.down,
    (a, b) => b.up - a.up || a.down - b.down,
    (a, b) => a.down - b.down || a.up - b.up,
    (a, b) => b.down - a.down || a.up - b.up
  ];

  resultsList.forEach(results => results.sort(sorters[sortIndex]));

  spanWiringResults.forEach((container, i) => {
    container.replaceChildren();
    resultsList[i].forEach(result => {
      const span = document.createElement("span");
      span.textContent = `${result.str}, `;
      span.title = `Delay: ${result.delay}, ↑: ${result.up}, ↓: ${result.down}`;
      span.tabIndex = 0;

      const show = () => drawWiring(result.str);
      span.addEventListener("click", show);
      span.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          show();
        }
      });
      container.append(span);
    });
  });

  const total = resultsList.reduce((sum, list) => sum + list.length, 0);
  message.textContent = total
    ? `一致 ${resultsList[0].length}件 / ±1f ${resultsList[1].length}件 / ±2f ${resultsList[2].length}件`
    : "該当する配線が見つかりませんでした。";

  if (checkWiringView.checked) {
    if (spanWiringResults[0].firstChild) {
      spanWiringResults[0].firstChild.click();
    } else if (spanWiringResults[1].firstChild) {
      spanWiringResults[1].firstChild.click();
    } else if (spanWiringResults[2].firstChild) {
      spanWiringResults[2].firstChild.click();
    } else {
      setCanvasHeight();
    }
  }
}

function findWiring() {
  const delay = inputWiringDelay.value.trim();
  const height = inputWiringHeight.value.trim();

  if (!isNum(delay, height) || Number(height) <= 0) {
    resultsList = undefined;
    clearResults();
    setCanvasHeight();
    message.textContent = "Delay と高さに整数を入力してください。";
    return;
  }

  resultsList = findWiringResults(parseInt(delay, 10), parseInt(height, 10));
  setWiringResult();
}

buttonFindWiring.addEventListener("click", findWiring);
selectWiringOrder.addEventListener("change", setWiringResult);

[inputWiringDelay, inputWiringHeight].forEach(input => {
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") findWiring();
  });
});

// 本家と同じく、表示用画像を先読みしておく。
[...partsNames, "note"].forEach(name => {
  const img = new Image();
  img.src = `images/railParts/${name}.png`;
});

setCanvasHeight();
